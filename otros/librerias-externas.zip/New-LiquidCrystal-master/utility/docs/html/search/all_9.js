var searchData=
[
  ['off',['off',['../class_l_c_d.html#a191639be183be1476c9bfe6d455d23b2',1,'LCD']]],
  ['on',['on',['../class_l_c_d.html#a718da3a638deb59bd1c7a5222a52d98a',1,'LCD']]]
];
